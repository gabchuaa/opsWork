package service;

import pojo.UserAccount;

public interface ServiceLogin {
	
	public void checkStatus(UserAccount ref);

}
