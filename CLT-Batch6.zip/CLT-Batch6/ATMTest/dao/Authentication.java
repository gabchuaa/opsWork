package dao;

import pojo1.UserAccount;

public interface Authentication {

	public boolean checkLogin(UserAccount ref);

	
}
