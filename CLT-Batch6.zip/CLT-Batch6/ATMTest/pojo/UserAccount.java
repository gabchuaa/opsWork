package pojo;

public class UserAccount {
	
	String loginID;
	int loginPW;
	
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public int getLoginPW() {
		return loginPW;
	}
	public void setLoginPW(int loginPW) {
		this.loginPW = loginPW;
	}
	
	

}
