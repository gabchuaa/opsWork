package day02;

class LoginCredential{
	
	void loginUser(String email,String password) {
		
	}// end of loginUser
	
	void loginUser(int mobile) {
		
	}// end of loginUser
	
	String loginUser(String thirdParty) {
		return thirdParty;
	}// end of loginUser

}// end of LoginCredential

public class MethodOverloadingExample2 {

	
	
	public static void main(String[]args) {
		
	}
}
