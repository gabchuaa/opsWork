package packA;

public class MyClassA {
	
	private   int number1 = 20;
			  int number2 = 30; // default
	protected int number3 = 40;
	public 	  int number4 = 50;
	
	
	void accessMyClassA() {//within the class
		
		System.out.println(number1);
		System.out.println(number2);
		System.out.println(number3);
		System.out.println(number4);
		
	}
	
	

}


