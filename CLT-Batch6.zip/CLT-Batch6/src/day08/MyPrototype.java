package day08;

public interface MyPrototype extends Cloneable {
	public MyPrototype clone() throws CloneNotSupportedException;

}
