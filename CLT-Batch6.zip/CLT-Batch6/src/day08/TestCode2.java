package day08;

import java.io.IOException;

import org.junit.Test;

public class TestCode2 {
	
	@Test
	public void testCase2() throws IOException {
		DevCode2.logic();
	}

}
