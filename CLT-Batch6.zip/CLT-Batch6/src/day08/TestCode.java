package day08;

import org.junit.Test;

public class TestCode {

	
	@Test
	public void MyTestCase1(){
		DevCode.login(10);
	}
}
