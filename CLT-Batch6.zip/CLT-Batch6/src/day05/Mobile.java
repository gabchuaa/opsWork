package day05;

public class Mobile {

	WhatsApp refWhatsApp;

	public WhatsApp getRefWhatsApp() { //Mobile has WhatsApp 
		return refWhatsApp;
	}

	public void setRefWhatsApp(WhatsApp refWhatsApp) {
		this.refWhatsApp = refWhatsApp;
	}
	
	
	
	
}
