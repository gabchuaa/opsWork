package day05;

public class Chat {
String chat; // Chat has String (text format)

public String getChat() {
	return chat;
}

public void setChat(String chat) {// hello will set here
	this.chat = chat;
}



}
