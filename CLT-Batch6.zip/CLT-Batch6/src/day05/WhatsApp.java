package day05;

public class WhatsApp {
	
	Chat refChat; //WhatsApp has Chat class

	public Chat getRefChat() {
		return refChat;
	}

	public void setRefChat(Chat refChat) {
		this.refChat = refChat;
	}

	
	

}
