package day05;

class Doctor{
	Medicine refMedicine; //must have ==> composition
	MarketingProduct refMarketingProduct; // optional ==> aggregation
}

// In Java, association can be done through using method or constructor

class MarketingProduct {
	
}

class Medicine{
	
}

public class AssocationExample01 {

}
