package factory;

public class DBSBank implements Bank {

	@Override
	public void offerCreditCard() {
		// TODO Auto-generated method stub
		System.out.println("DBS ==> CreditCard");

	}

}
