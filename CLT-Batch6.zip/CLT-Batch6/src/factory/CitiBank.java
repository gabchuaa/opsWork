package factory;

public class CitiBank implements Bank {

	@Override
	public void offerCreditCard() {
		// TODO Auto-generated method stub
		System.out.println("CitiBank ==> CreditCard");

	}

}
