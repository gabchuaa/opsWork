package factory;

public interface Bank {

	void offerCreditCard();
	
	
}
