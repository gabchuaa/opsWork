package factory;

public class OtherBank implements Bank {

	@Override
	public void offerCreditCard() {
		// TODO Auto-generated method stub
		System.out.println(" No offer found");

	}

}
