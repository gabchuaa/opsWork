package coreJavaOOP;

public class Problem3 {
public static void main(String []args) {
		
		int i,j;
		for(i=1; i<=6; i++) {
			for(j=0; j<i;j++) {
				System.out.print((char)(i+64));
			}
			System.out.println();
			
		}
	}

}
