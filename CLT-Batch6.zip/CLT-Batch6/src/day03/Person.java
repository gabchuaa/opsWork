package day03;

public class Person {
	String name ="Tom";

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}
	
	
	

}
