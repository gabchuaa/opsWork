package service;

import pojo.User;

public interface LoginService {
	void checkStatus(User ref);

}
