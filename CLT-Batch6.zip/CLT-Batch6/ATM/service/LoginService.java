package service;

import pojo1.User;

public interface LoginService {
	void checkStatus(User ref);

}
