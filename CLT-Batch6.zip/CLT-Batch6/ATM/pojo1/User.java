package pojo1;

public class User {

	private int userID;
	private String userPassword;

	//Getter
	public int getUserID() {
		return userID;
	}

	public String getUserPassword() {
		return userPassword;
	}

	//Setter
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

}
