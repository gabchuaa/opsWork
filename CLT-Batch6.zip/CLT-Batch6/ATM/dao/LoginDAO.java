package dao;

import pojo1.User;

public interface LoginDAO {
	boolean loginValidate(User ref);
	
}
