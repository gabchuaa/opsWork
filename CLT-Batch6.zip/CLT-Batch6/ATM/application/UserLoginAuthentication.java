package application;

import controller.LoginController;

public class UserLoginAuthentication {

	public static void main(String []args) {
		LoginController refLoginController = new LoginController();
		refLoginController.userLoginController();
		
	}
	
}
